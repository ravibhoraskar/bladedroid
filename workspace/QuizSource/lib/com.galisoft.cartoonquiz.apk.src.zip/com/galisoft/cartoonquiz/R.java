package com.galisoft.cartoonquiz;

public final class R
{
  public static final class attr
  {
  }

  public static final class drawable
  {
    public static final int abejamayamayathebee = 2130837504;
    public static final int abrahamsimpson = 2130837505;
    public static final int agumon = 2130837506;
    public static final int aladdin = 2130837507;
    public static final int ash = 2130837508;
    public static final int asterix = 2130837509;
    public static final int bambi = 2130837510;
    public static final int bart = 2130837511;
    public static final int batman = 2130837512;
    public static final int ben10 = 2130837513;
    public static final int bender = 2130837514;
    public static final int benji = 2130837515;
    public static final int bobesponja = 2130837516;
    public static final int brock = 2130837517;
    public static final int bubu = 2130837518;
    public static final int bugsbunny = 2130837519;
    public static final int buttonestandar = 2130837520;
    public static final int buttong = 2130837521;
    public static final int buttonr = 2130837522;
    public static final int calamardo = 2130837523;
    public static final int calimero = 2130837524;
    public static final int campanilla = 2130837525;
    public static final int capitanamerica = 2130837526;
    public static final int cartman = 2130837527;
    public static final int catdoggatocan = 2130837528;
    public static final int cell = 2130837529;
    public static final int chavo = 2130837530;
    public static final int ciclope = 2130837531;
    public static final int conan = 2130837532;
    public static final int correcaminos = 2130837533;
    public static final int cowchickenvacaypollo = 2130837534;
    public static final int coyote = 2130837535;
    public static final int dexter = 2130837536;
    public static final int doraemon = 2130837537;
    public static final int droopy = 2130837538;
    public static final int flash = 2130837539;
    public static final int fondocartoon = 2130837540;
    public static final int garfield = 2130837541;
    public static final int garyoak = 2130837542;
    public static final int genio = 2130837543;
    public static final int glennquagmire = 2130837544;
    public static final int goofy = 2130837545;
    public static final int greenarrow = 2130837546;
    public static final int hamtaro = 2130837547;
    public static final int heidi = 2130837548;
    public static final int homersimpsonhomero = 2130837549;
    public static final int ic_launcher = 2130837550;
    public static final int ico = 2130837551;
    public static final int inspectorgaddget = 2130837552;
    public static final int jimmyneutron = 2130837553;
    public static final int johnnybravo = 2130837554;
    public static final int joker = 2130837555;
    public static final int kakashihatake = 2130837556;
    public static final int kenny = 2130837557;
    public static final int kentbrockman = 2130837558;
    public static final int kimpossible = 2130837559;
    public static final int krasty = 2130837560;
    public static final int laschicassuperpoderosasthepowerpuffgirls = 2130837561;
    public static final int lasirenita = 2130837562;
    public static final int leelaturanga = 2130837563;
    public static final int lennyleonard = 2130837564;
    public static final int lilostitch = 2130837565;
    public static final int lisa = 2130837566;
    public static final int loisgriffin = 2130837567;
    public static final int lossupersonicos = 2130837568;
    public static final int lovezno = 2130837569;
    public static final int maggieimpson = 2130837570;
    public static final int magneto = 2130837571;
    public static final int marco = 2130837572;
    public static final int mazingerz = 2130837573;
    public static final int meggriffin = 2130837574;
    public static final int misaamane = 2130837575;
    public static final int misty = 2130837576;
    public static final int moeszyslak = 2130837577;
    public static final int narutouzumaki = 2130837578;
    public static final int nedflanders = 2130837579;
    public static final int nemo = 2130837580;
    public static final int oak = 2130837581;
    public static final int obelix = 2130837582;
    public static final int oliver = 2130837583;
    public static final int osoyogi = 2130837584;
    public static final int panterarosa = 2130837585;
    public static final int patolucas = 2130837586;
    public static final int pedropicapiedra = 2130837587;
    public static final int petergriffin = 2130837588;
    public static final int peterpan = 2130837589;
    public static final int philipjfry = 2130837590;
    public static final int picachu = 2130837591;
    public static final int piccolo = 2130837592;
    public static final int pinguinosdemadagascar = 2130837593;
    public static final int pitufos = 2130837594;
    public static final int popeye = 2130837595;
    public static final int pumba = 2130837596;
    public static final int rascapica = 2130837597;
    public static final int sailormoon = 2130837598;
    public static final int sasukeuchiha = 2130837599;
    public static final int scoobydoo = 2130837600;
    public static final int silvestre = 2130837601;
    public static final int simpsonmarge = 2130837602;
    public static final int sinchan = 2130837603;
    public static final int snoopy = 2130837604;
    public static final int songoku = 2130837605;
    public static final int speedygonzales = 2130837606;
    public static final int spiderman = 2130837607;
    public static final int stewiegriffin = 2130837608;
    public static final int superman = 2130837609;
    public static final int supervegeta = 2130837610;
    public static final int taz = 2130837611;
    public static final int timon = 2130837612;
    public static final int tintin = 2130837613;
    public static final int tommypickles = 2130837614;
    public static final int tomyjerry = 2130837615;
    public static final int tormenta = 2130837616;
    public static final int tweetypiolin = 2130837617;
    public static final int vilmapicapiedra = 2130837618;
    public static final int woodywoodpeckerpajaroloco = 2130837619;
    public static final int yagamiraitokira = 2130837620;
  }

  public static final class id
  {
    public static final int adView = 2131034116;
    public static final int ad_holder = 2131034123;
    public static final int button1 = 2131034131;
    public static final int button2 = 2131034130;
    public static final int button3 = 2131034129;
    public static final int button4 = 2131034128;
    public static final int buttonAyuda = 2131034120;
    public static final int buttonJugar = 2131034119;
    public static final int buttonSalir = 2131034121;
    public static final int buttonVolver = 2131034114;
    public static final int buttonmoreapp = 2131034122;
    public static final int buttonvolvermenu = 2131034115;
    public static final int imageView1 = 2131034132;
    public static final int relativeLayout = 2131034124;
    public static final int relativeLayout1 = 2131034125;
    public static final int relativeLayoutf = 2131034117;
    public static final int relativeLayoutm = 2131034118;
    public static final int textViewAyuda = 2131034112;
    public static final int textViewFin = 2131034113;
    public static final int textViewPuntos = 2131034126;
    public static final int textViewTiempo = 2131034127;
  }

  public static final class layout
  {
    public static final int ayuda = 2130903040;
    public static final int fin = 2130903041;
    public static final int main = 2130903042;
    public static final int quiz = 2130903043;
  }

  public static final class string
  {
    public static final int BotonPregunta = 2130968579;
    public static final int BotonSalir = 2130968580;
    public static final int ImagenPortada = 2130968577;
    public static final int Imagendeljugador = 2130968578;
    public static final int StringOkay = 2130968581;
    public static final int app_name = 2130968576;
    public static final int ayuda = 2130968588;
    public static final int continuar = 2130968592;
    public static final int fin1 = 2130968593;
    public static final int fin2 = 2130968594;
    public static final int finalizar = 2130968591;
    public static final int juegoPausado = 2130968590;
    public static final int jugar = 2130968585;
    public static final int moreapp = 2130968595;
    public static final int puntos = 2130968583;
    public static final int salir = 2130968586;
    public static final int textayuda = 2130968589;
    public static final int tiempo = 2130968582;
    public static final int vm2 = 2130968584;
    public static final int volverajugar = 2130968587;
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.galisoft.cartoonquiz.R
 * JD-Core Version:    0.6.0
 */