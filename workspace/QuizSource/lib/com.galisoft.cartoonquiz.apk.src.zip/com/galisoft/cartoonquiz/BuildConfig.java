package com.galisoft.cartoonquiz;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.galisoft.cartoonquiz.BuildConfig
 * JD-Core Version:    0.6.0
 */