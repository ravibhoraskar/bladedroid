package com.galisoft.cartoonquiz;

public class Datos
{
  boolean isPremium;
  String name;
  int resID;

  Datos()
  {
  }

  Datos(String paramString, int paramInt, boolean paramBoolean)
  {
    this.name = paramString;
    this.resID = paramInt;
    this.isPremium = paramBoolean;
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.galisoft.cartoonquiz.Datos
 * JD-Core Version:    0.6.0
 */