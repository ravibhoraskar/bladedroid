package com.galisoft.cartoonquiz;

import android.app.Activity;
import android.os.Bundle;

public class CartoonQuizActivity extends Activity
{
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903042);
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.galisoft.cartoonquiz.CartoonQuizActivity
 * JD-Core Version:    0.6.0
 */