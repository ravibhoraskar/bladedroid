package com.galisoft.cartoonquiz;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class AyudaActivity extends Activity
{
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    ((TextView)findViewById(2131034112)).setText(2130968589);
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.galisoft.cartoonquiz.AyudaActivity
 * JD-Core Version:    0.6.0
 */