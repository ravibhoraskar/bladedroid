package com.galisoft.cartoonquiz;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.ads.AdRequest;
import com.google.ads.AdView;
import java.util.ArrayList;

public class ActivityQuizScreen extends Activity
{
  boolean JuegoParado = false;
  Bundle b;
  ArrayList<Button> botonPreguntas = new ArrayList();
  boolean botonactivado = true;
  CountDownTimer cuentaAtras;
  ImageView jugadorImagen;
  String levelString;
  ArrayList<Datos> listadatos = new ArrayList();
  String name;
  int nivel;
  boolean pausa = false;
  boolean pausaJuego = true;
  int pregunta;
  int puntos = 0;
  int respuesta;
  int segundos = 60;
  TextView textopuntos;
  TextView textotiempo;

  private void addJugadores()
  {
    this.listadatos.add(new Datos("Maya the Bee / Abeja Maya", 2130837504, false));
    this.listadatos.add(new Datos("Abraham Simpson", 2130837505, false));
    this.listadatos.add(new Datos("Agumon", 2130837506, false));
    this.listadatos.add(new Datos("Ash", 2130837508, false));
    this.listadatos.add(new Datos("Asterix", 2130837509, false));
    this.listadatos.add(new Datos("Bart", 2130837511, false));
    this.listadatos.add(new Datos("Ben 10", 2130837513, false));
    this.listadatos.add(new Datos("Bender", 2130837514, false));
    this.listadatos.add(new Datos("Benji", 2130837515, false));
    this.listadatos.add(new Datos("Bob Esponja", 2130837516, false));
    this.listadatos.add(new Datos("Brok", 2130837517, false));
    this.listadatos.add(new Datos("Bubu", 2130837518, false));
    this.listadatos.add(new Datos("Bugs Bunny", 2130837519, false));
    this.listadatos.add(new Datos("Calamardo", 2130837523, false));
    this.listadatos.add(new Datos("Cartman", 2130837527, false));
    this.listadatos.add(new Datos("CatDog / Gatocan", 2130837528, false));
    this.listadatos.add(new Datos("Cell", 2130837529, false));
    this.listadatos.add(new Datos("Chavo", 2130837530, false));
    this.listadatos.add(new Datos("Ciclope", 2130837531, false));
    this.listadatos.add(new Datos("Conan", 2130837532, false));
    this.listadatos.add(new Datos("Road Runner / Correcaminos", 2130837533, false));
    this.listadatos.add(new Datos("Cowchicken / Vacaypollo", 2130837534, false));
    this.listadatos.add(new Datos("Coyote", 2130837535, false));
    this.listadatos.add(new Datos("Dexter", 2130837536, false));
    this.listadatos.add(new Datos("Doraemon", 2130837537, false));
    this.listadatos.add(new Datos("Droppy", 2130837538, false));
    this.listadatos.add(new Datos("Fash", 2130837539, false));
    this.listadatos.add(new Datos("Garfield", 2130837541, false));
    this.listadatos.add(new Datos("Gary Oak", 2130837542, false));
    this.listadatos.add(new Datos("Glenn Quagmire", 2130837544, false));
    this.listadatos.add(new Datos("Green Arrow / Flecha Verde", 2130837546, false));
    this.listadatos.add(new Datos("Hamtaro", 2130837547, false));
    this.listadatos.add(new Datos("Heidi", 2130837548, false));
    this.listadatos.add(new Datos("Homer Simpson / Homero", 2130837549, false));
    this.listadatos.add(new Datos("Inspector Gadget", 2130837552, false));
    this.listadatos.add(new Datos("Jimmy Neutron", 2130837553, false));
    this.listadatos.add(new Datos("johnny Bravo", 2130837554, false));
    this.listadatos.add(new Datos("Kakashi Hatake", 2130837556, false));
    this.listadatos.add(new Datos("Kenny", 2130837557, false));
    this.listadatos.add(new Datos("Kent Brockman", 2130837558, false));
    this.listadatos.add(new Datos("Kim possible", 2130837559, false));
    this.listadatos.add(new Datos("Krasty", 2130837560, false));
    this.listadatos.add(new Datos("The powerpuff girls", 2130837561, false));
    this.listadatos.add(new Datos("Leela Turanga", 2130837563, false));
    this.listadatos.add(new Datos("Lenny Leonard", 2130837564, false));
    this.listadatos.add(new Datos("Lilostitch", 2130837565, false));
    this.listadatos.add(new Datos("Lisa", 2130837566, false));
    this.listadatos.add(new Datos("Lois Griffin", 2130837567, false));
    this.listadatos.add(new Datos("The Supersonics / Los Supersonicos", 2130837568, false));
    this.listadatos.add(new Datos("Lovezno", 2130837569, false));
    this.listadatos.add(new Datos("Maggie Simpson", 2130837570, false));
    this.listadatos.add(new Datos("Magneto", 2130837571, false));
    this.listadatos.add(new Datos("Marco", 2130837572, false));
    this.listadatos.add(new Datos("Mazinger Z", 2130837573, false));
    this.listadatos.add(new Datos("Meg Griffin", 2130837574, false));
    this.listadatos.add(new Datos("Misa Aname", 2130837575, false));
    this.listadatos.add(new Datos("Misty", 2130837576, false));
    this.listadatos.add(new Datos("Moe Szyslak", 2130837577, false));
    this.listadatos.add(new Datos("Naruto Uzumaki", 2130837578, false));
    this.listadatos.add(new Datos("Ned Flanders", 2130837579, false));
    this.listadatos.add(new Datos("Oak", 2130837581, false));
    this.listadatos.add(new Datos("Obelix", 2130837582, false));
    this.listadatos.add(new Datos("Oliver", 2130837583, false));
    this.listadatos.add(new Datos("Oso Yogi", 2130837584, false));
    this.listadatos.add(new Datos("Pink Panther /Pantera Rosa", 2130837585, false));
    this.listadatos.add(new Datos("Lucas Sheldom Pato / Pato Lucas", 2130837586, false));
    this.listadatos.add(new Datos("Fred Flintstone / Pedro Picapiedra", 2130837587, false));
    this.listadatos.add(new Datos("Peter Grifiien", 2130837588, false));
    this.listadatos.add(new Datos("Philip J.fry", 2130837590, false));
    this.listadatos.add(new Datos("Picachu", 2130837591, false));
    this.listadatos.add(new Datos("Piccolo", 2130837592, false));
    this.listadatos.add(new Datos("The Penguins of Madagascar", 2130837593, false));
    this.listadatos.add(new Datos("Pitufos", 2130837594, false));
    this.listadatos.add(new Datos("Popeye", 2130837595, false));
    this.listadatos.add(new Datos("Pumba", 2130837596, false));
    this.listadatos.add(new Datos("Rasca Pica", 2130837597, false));
    this.listadatos.add(new Datos("Sailormoon", 2130837598, false));
    this.listadatos.add(new Datos("Sasuke Uchiha", 2130837599, false));
    this.listadatos.add(new Datos("Scoobydoo", 2130837600, false));
    this.listadatos.add(new Datos("Silvestre", 2130837601, false));
    this.listadatos.add(new Datos("Marge Simpson", 2130837602, false));
    this.listadatos.add(new Datos("Sinchan", 2130837603, false));
    this.listadatos.add(new Datos("Snoopy", 2130837604, false));
    this.listadatos.add(new Datos("Songoku", 2130837605, false));
    this.listadatos.add(new Datos("Speedy Gonzales", 2130837606, false));
    this.listadatos.add(new Datos("Spiderman", 2130837607, false));
    this.listadatos.add(new Datos("Stewie Griffin", 2130837608, false));
    this.listadatos.add(new Datos("Superman", 2130837609, false));
    this.listadatos.add(new Datos("Super Vegeta", 2130837610, false));
    this.listadatos.add(new Datos("Taz", 2130837611, false));
    this.listadatos.add(new Datos("Timon", 2130837612, false));
    this.listadatos.add(new Datos("Tintin", 2130837613, false));
    this.listadatos.add(new Datos("Tommy Pickles", 2130837614, false));
    this.listadatos.add(new Datos("Tomy Jerry", 2130837615, false));
    this.listadatos.add(new Datos("Strom / Tormenta", 2130837616, false));
    this.listadatos.add(new Datos("Tweety / Piolin", 2130837617, false));
    this.listadatos.add(new Datos("Wilma Flintstone/ Vilma Picapiedra", 2130837618, false));
    this.listadatos.add(new Datos("Woody Woodpeker / Pajaro Loco", 2130837619, false));
    this.listadatos.add(new Datos("Yagami Kira", 2130837620, false));
    this.listadatos.add(new Datos("Ariel", 2130837562, false));
    this.listadatos.add(new Datos("Bambi", 2130837510, false));
    this.listadatos.add(new Datos("Tinker Bell / Campanita", 2130837525, false));
    this.listadatos.add(new Datos("Cap. American / Cap. America", 2130837526, false));
    this.listadatos.add(new Datos("Goofy", 2130837545, false));
    this.listadatos.add(new Datos("Nemo", 2130837580, false));
    this.listadatos.add(new Datos("Joker", 2130837555, false));
    this.listadatos.add(new Datos("Calimero / Karimero", 2130837524, false));
    this.listadatos.add(new Datos("Genius / Genio", 2130837543, false));
    this.listadatos.add(new Datos("Peter Pan", 2130837589, false));
    this.listadatos.add(new Datos("Aladdin", 2130837507, false));
  }

  private void elijaJugador()
  {
    ArrayList localArrayList1 = (ArrayList)this.listadatos.clone();
    ArrayList localArrayList2 = (ArrayList)this.botonPreguntas.clone();
    Datos localDatos1 = (Datos)localArrayList1.get((int)Math.round(Math.random() * localArrayList1.size() - 0.5D));
    Log.d("wot", localDatos1.name);
    int i;
    if (localDatos1.name != "Typ 59")
    {
      this.jugadorImagen.setImageResource(Integer.valueOf(localDatos1.resID).intValue());
      localArrayList1.remove(localDatos1);
      this.pregunta = (int)Math.round(0.5D + Math.random() * localArrayList2.size());
      ((Button)localArrayList2.get(-1 + this.pregunta)).setText(localDatos1.name);
      localArrayList2.remove(-1 + this.pregunta);
      i = 1;
      label146: if (i <= 3)
        break label195;
    }
    label152: for (int k = 0; ; k++)
    {
      if (k > -1 + localArrayList2.size())
      {
        return;
        localDatos1 = (Datos)localArrayList1.get((int)Math.round(Math.random() * localArrayList1.size() - 0.5D));
        break;
        label195: if (localArrayList1.size() == 0)
          break label152;
        Datos localDatos2 = (Datos)localArrayList1.get((int)Math.round(Math.random() * localArrayList1.size() - 0.5D));
        localArrayList1.remove(localDatos2);
        int j = (int)Math.round(0.5D + Math.random() * localArrayList2.size());
        ((Button)localArrayList2.get(j - 1)).setText(localDatos2.name);
        localArrayList2.remove(j - 1);
        i++;
        break label146;
      }
      ((Button)localArrayList2.get(k)).setText("");
    }
  }

  public void BotonPregunta(View paramView)
  {
    if ((this.botonactivado) && (!this.JuegoParado))
    {
      this.botonactivado = false;
      switch (((Button)paramView).getId())
      {
      default:
      case 2131034131:
      case 2131034130:
      case 2131034129:
      case 2131034128:
      }
    }
    while (this.respuesta == this.pregunta)
    {
      this.puntos = (1 + this.puntos);
      this.textopuntos.setText(getString(2130968583) + " " + Integer.toString(this.puntos));
      ((Button)this.botonPreguntas.get(-1 + this.pregunta)).setBackgroundResource(2130837521);
      new Handler().postDelayed(new Runnable()
      {
        public void run()
        {
          ((Button)ActivityQuizScreen.this.botonPreguntas.get(-1 + ActivityQuizScreen.this.pregunta)).setBackgroundResource(2130837520);
          ActivityQuizScreen.this.elijaJugador();
          ActivityQuizScreen.this.botonactivado = true;
        }
      }
      , 200L);
      return;
      this.respuesta = 1;
      continue;
      this.respuesta = 2;
      continue;
      this.respuesta = 3;
      continue;
      this.respuesta = 4;
    }
    this.puntos = (-1 + this.puntos);
    this.textopuntos.setText(getString(2130968583) + " " + Integer.toString(this.puntos));
    ((Button)this.botonPreguntas.get(-1 + this.respuesta)).setBackgroundResource(2130837522);
    ((Button)this.botonPreguntas.get(-1 + this.pregunta)).setBackgroundResource(2130837521);
    new Handler().postDelayed(new Runnable()
    {
      public void run()
      {
        ((Button)ActivityQuizScreen.this.botonPreguntas.get(-1 + ActivityQuizScreen.this.respuesta)).setBackgroundResource(2130837520);
        ((Button)ActivityQuizScreen.this.botonPreguntas.get(-1 + ActivityQuizScreen.this.pregunta)).setBackgroundResource(2130837520);
        ActivityQuizScreen.this.elijaJugador();
        ActivityQuizScreen.this.botonactivado = true;
      }
    }
    , 1000L);
  }

  public void empezarCuentaAtras()
  {
    this.cuentaAtras = new CountDownTimer(1000 * this.segundos, 1000L)
    {
      public void onFinish()
      {
        ActivityQuizScreen.this.JuegoParado = true;
        ActivityQuizScreen.this.pausaJuego = false;
        Intent localIntent = new Intent(ActivityQuizScreen.this, FinActivity.class);
        localIntent.putExtra("puntos", ActivityQuizScreen.this.puntos);
        ActivityQuizScreen.this.startActivity(localIntent);
      }

      public void onTick(long paramLong)
      {
        ActivityQuizScreen localActivityQuizScreen = ActivityQuizScreen.this;
        localActivityQuizScreen.segundos = (-1 + localActivityQuizScreen.segundos);
        ActivityQuizScreen.this.textotiempo.setText(ActivityQuizScreen.this.getString(2130968582) + " " + Integer.toString(ActivityQuizScreen.this.segundos));
      }
    };
    this.cuentaAtras.start();
  }

  public void onBackPressed()
  {
    pause();
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903043);
    ((AdView)findViewById(2131034116)).loadAd(new AdRequest());
    this.b = getIntent().getExtras();
    if (this.b != null)
      this.nivel = this.b.getInt("nivel");
    this.jugadorImagen = ((ImageView)findViewById(2131034132));
    this.textopuntos = ((TextView)findViewById(2131034126));
    this.textotiempo = ((TextView)findViewById(2131034127));
    this.botonPreguntas.add((Button)findViewById(2131034131));
    this.botonPreguntas.add((Button)findViewById(2131034130));
    this.botonPreguntas.add((Button)findViewById(2131034129));
    this.botonPreguntas.add((Button)findViewById(2131034128));
    this.textopuntos.setText(getString(2130968583) + " " + this.puntos);
    this.textotiempo.setText(getString(2130968582) + " " + this.segundos);
    addJugadores();
    elijaJugador();
    empezarCuentaAtras();
  }

  public void onPause()
  {
    super.onStop();
    pause();
  }

  public boolean onPrepareOptionsMenu(Menu paramMenu)
  {
    pause();
    return true;
  }

  protected void pause()
  {
    if ((this.pausaJuego) && (!this.pausa))
    {
      this.pausa = true;
      this.cuentaAtras.cancel();
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(this);
      localBuilder.setTitle(2130968590);
      localBuilder.setPositiveButton(2130968592, new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramDialogInterface, int paramInt)
        {
          ActivityQuizScreen.this.empezarCuentaAtras();
          ActivityQuizScreen.this.pausa = false;
        }
      });
      localBuilder.setNegativeButton(2130968591, new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramDialogInterface, int paramInt)
        {
          ActivityQuizScreen.this.finish();
        }
      });
      localBuilder.setOnCancelListener(new DialogInterface.OnCancelListener()
      {
        public void onCancel(DialogInterface paramDialogInterface)
        {
          ActivityQuizScreen.this.empezarCuentaAtras();
          ActivityQuizScreen.this.pausa = false;
        }
      });
      localBuilder.create().show();
    }
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.galisoft.cartoonquiz.ActivityQuizScreen
 * JD-Core Version:    0.6.0
 */