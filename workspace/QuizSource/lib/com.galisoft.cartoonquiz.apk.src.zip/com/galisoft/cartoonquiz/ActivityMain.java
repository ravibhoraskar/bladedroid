package com.galisoft.cartoonquiz;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import com.google.ads.AdRequest;
import com.google.ads.AdView;

public class ActivityMain extends Activity
{
  public void Ayuda(View paramView)
  {
    startActivity(new Intent(this, AyudaActivity.class));
  }

  public void BotonSalir(View paramView)
  {
    Intent localIntent = new Intent("android.intent.action.MAIN");
    localIntent.addCategory("android.intent.category.HOME");
    localIntent.setFlags(268435456);
    startActivity(localIntent);
  }

  public void Jugar(View paramView)
  {
    startActivity(new Intent(this, ActivityQuizScreen.class));
  }

  public void MoreApp(View paramView)
  {
    startActivity(new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/search?q=pub:Galisoft")));
  }

  public void onBackPressed()
  {
    Intent localIntent = new Intent("android.intent.action.MAIN");
    localIntent.addCategory("android.intent.category.HOME");
    localIntent.setFlags(268435456);
    startActivity(localIntent);
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903042);
    ((AdView)findViewById(2131034116)).loadAd(new AdRequest());
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.galisoft.cartoonquiz.ActivityMain
 * JD-Core Version:    0.6.0
 */