package com.galisoft.cartoonquiz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import com.google.ads.AdRequest;
import com.google.ads.AdView;

public class FinActivity extends Activity
{
  public void BotonVolverMenu(View paramView)
  {
    startActivity(new Intent(this, ActivityMain.class));
    finish();
  }

  public void onBackPressed()
  {
    startActivity(new Intent(this, ActivityMain.class));
    finish();
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903041);
    ((AdView)findViewById(2131034116)).loadAd(new AdRequest());
    int i = getIntent().getExtras().getInt("puntos");
    ((TextView)findViewById(2131034113)).setText(getString(2130968593) + " " + String.valueOf(i) + " " + getString(2130968594));
    ((Button)findViewById(2131034114)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramView)
      {
        Intent localIntent = new Intent(FinActivity.this, ActivityQuizScreen.class);
        FinActivity.this.startActivity(localIntent);
      }
    });
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.galisoft.cartoonquiz.FinActivity
 * JD-Core Version:    0.6.0
 */