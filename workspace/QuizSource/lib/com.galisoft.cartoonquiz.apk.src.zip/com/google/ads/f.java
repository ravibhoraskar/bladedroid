package com.google.ads;

import com.google.ads.util.a;
import java.util.List;

public class f
{
  private final String a;
  private final String b;
  private final String c;
  private final List<String> d;
  private final List<String> e;
  private final List<String> f;

  public f(String paramString1, String paramString2, String paramString3, List<String> paramList1, List<String> paramList2, List<String> paramList3)
  {
    a.a(paramString2);
    if (paramString1 != null)
      a.a(paramString1);
    a.a(paramString3);
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.d = paramList1;
    this.e = paramList2;
    this.f = paramList3;
  }

  public String a()
  {
    return this.a;
  }

  public String b()
  {
    return this.b;
  }

  public String c()
  {
    return this.c;
  }

  public List<String> d()
  {
    return this.d;
  }

  public List<String> e()
  {
    return this.e;
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.f
 * JD-Core Version:    0.6.0
 */