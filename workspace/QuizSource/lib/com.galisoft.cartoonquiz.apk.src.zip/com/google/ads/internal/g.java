package com.google.ads.internal;

import android.os.SystemClock;
import com.google.ads.util.b;
import java.util.LinkedList;

public class g
{
  private static long f = 0L;
  private static long h = -1L;
  public String a;
  private LinkedList<Long> b = new LinkedList();
  private long c;
  private long d;
  private LinkedList<Long> e = new LinkedList();
  private String g;
  private boolean i = false;
  private boolean j = false;

  protected g()
  {
    a();
  }

  public static long q()
  {
    if (h == -1L)
    {
      h = SystemClock.elapsedRealtime();
      return 0L;
    }
    return SystemClock.elapsedRealtime() - h;
  }

  protected void a()
  {
    this.b.clear();
    this.c = 0L;
    this.d = 0L;
    this.e.clear();
    this.g = null;
    this.i = false;
    this.j = false;
  }

  public void a(String paramString)
  {
    b.d("Prior ad identifier = " + paramString);
    this.g = paramString;
  }

  protected void b()
  {
    b.d("Ad clicked.");
    this.b.add(Long.valueOf(SystemClock.elapsedRealtime()));
  }

  public void b(String paramString)
  {
    b.d("Prior impression ticket = " + paramString);
    this.a = paramString;
  }

  protected void c()
  {
    b.d("Ad request loaded.");
    this.c = SystemClock.elapsedRealtime();
  }

  protected void d()
  {
    b.d("Ad request started.");
    this.d = SystemClock.elapsedRealtime();
    f = 1L + f;
  }

  protected long e()
  {
    if (this.b.size() != this.e.size())
      return -1L;
    return this.b.size();
  }

  protected String f()
  {
    if ((this.b.isEmpty()) || (this.b.size() != this.e.size()))
      return null;
    StringBuilder localStringBuilder = new StringBuilder();
    for (int k = 0; k < this.b.size(); k++)
    {
      if (k != 0)
        localStringBuilder.append(",");
      localStringBuilder.append(Long.toString(((Long)this.e.get(k)).longValue() - ((Long)this.b.get(k)).longValue()));
    }
    return localStringBuilder.toString();
  }

  protected String g()
  {
    if (this.b.isEmpty())
      return null;
    StringBuilder localStringBuilder = new StringBuilder();
    for (int k = 0; k < this.b.size(); k++)
    {
      if (k != 0)
        localStringBuilder.append(",");
      localStringBuilder.append(Long.toString(((Long)this.b.get(k)).longValue() - this.c));
    }
    return localStringBuilder.toString();
  }

  protected long h()
  {
    return this.c - this.d;
  }

  protected long i()
  {
    return f;
  }

  protected String j()
  {
    return this.g;
  }

  protected boolean k()
  {
    return this.i;
  }

  protected void l()
  {
    b.d("Interstitial network error.");
    this.i = true;
  }

  protected boolean m()
  {
    return this.j;
  }

  protected void n()
  {
    b.d("Interstitial no fill.");
    this.j = true;
  }

  public void o()
  {
    b.d("Landing page dismissed.");
    this.e.add(Long.valueOf(SystemClock.elapsedRealtime()));
  }

  protected String p()
  {
    return this.a;
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.internal.g
 * JD-Core Version:    0.6.0
 */