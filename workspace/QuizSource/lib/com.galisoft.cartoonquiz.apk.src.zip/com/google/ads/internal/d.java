package com.google.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import com.google.ads.Ad;
import com.google.ads.AdActivity;
import com.google.ads.AdListener;
import com.google.ads.AdRequest;
import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.AdView;
import com.google.ads.aa;
import com.google.ads.ab;
import com.google.ads.ae;
import com.google.ads.f;
import com.google.ads.l;
import com.google.ads.l.a;
import com.google.ads.m;
import com.google.ads.util.AdUtil;
import com.google.ads.util.i.b;
import com.google.ads.util.i.c;
import com.google.ads.util.i.d;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class d
{
  private static final Object a = new Object();
  private final m b;
  private c c;
  private AdRequest d;
  private g e;
  private AdWebView f;
  private i g;
  private Handler h;
  private long i;
  private boolean j;
  private boolean k;
  private boolean l;
  private boolean m;
  private SharedPreferences n;
  private long o;
  private ab p;
  private boolean q;
  private LinkedList<String> r;
  private LinkedList<String> s;
  private int t = -1;
  private Boolean u;
  private com.google.ads.d v;
  private com.google.ads.e w;
  private f x;
  private String y = null;

  public d(m paramm, boolean paramBoolean)
  {
    this.b = paramm;
    this.q = paramBoolean;
    this.e = new g();
    this.c = null;
    this.d = null;
    this.k = false;
    this.h = new Handler();
    this.o = 0L;
    this.l = false;
    this.m = true;
    if ((paramm == null) || (paramm.d.a() == null))
      return;
    while (true)
    {
      synchronized (a)
      {
        this.n = ((Context)paramm.d.a()).getSharedPreferences("GoogleAdMobAdsPrefs", 0);
        if (paramBoolean)
        {
          long l1 = this.n.getLong("Timeout" + paramm.b, -1L);
          if (l1 >= 0L)
            continue;
          this.i = 5000L;
          this.p = new ab(this);
          this.r = new LinkedList();
          this.s = new LinkedList();
          a();
          AdUtil.h((Context)paramm.d.a());
          this.v = new com.google.ads.d();
          this.w = new com.google.ads.e(this);
          this.u = null;
          this.x = null;
          return;
          this.i = l1;
        }
      }
      this.i = 60000L;
    }
  }

  private void a(f paramf, Boolean paramBoolean)
  {
    Object localObject = paramf.d();
    if (localObject == null)
    {
      localObject = new ArrayList();
      ((List)localObject).add("http://e.admob.com/imp?ad_loc=@gw_adlocid@&qdata=@gw_qdata@&ad_network_id=@gw_adnetid@&js=@gw_sdkver@&session_id=@gw_sessid@&seq_num=@gw_seqnum@&nr=@gw_adnetrefresh@");
    }
    String str = paramf.b();
    a((List)localObject, paramf.a(), str, paramf.c(), paramBoolean);
  }

  private void a(List<String> paramList, String paramString)
  {
    Object localObject;
    if (paramList == null)
    {
      localObject = new ArrayList();
      ((List)localObject).add("http://e.admob.com/nofill?ad_loc=@gw_adlocid@&qdata=@gw_qdata@&js=@gw_sdkver@&session_id=@gw_sessid@&seq_num=@gw_seqnum@");
    }
    while (true)
    {
      a((List)localObject, null, null, paramString, null);
      return;
      localObject = paramList;
    }
  }

  private void a(List<String> paramList, String paramString1, String paramString2, String paramString3, Boolean paramBoolean)
  {
    String str1 = AdUtil.a((Context)this.b.d.a());
    com.google.ads.b localb = com.google.ads.b.a();
    String str2 = localb.b().toString();
    String str3 = localb.c().toString();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
      new Thread(new aa(com.google.ads.g.a((String)localIterator.next(), (String)this.b.b.a(), paramBoolean, str1, paramString1, paramString2, paramString3, str2, str3), (Context)this.b.d.a())).start();
  }

  private void b(f paramf, Boolean paramBoolean)
  {
    Object localObject = paramf.e();
    if (localObject == null)
    {
      localObject = new ArrayList();
      ((List)localObject).add("http://e.admob.com/clk?ad_loc=@gw_adlocid@&qdata=@gw_qdata@&ad_network_id=@gw_adnetid@&js=@gw_sdkver@&session_id=@gw_sessid@&seq_num=@gw_seqnum@&nr=@gw_adnetrefresh@");
    }
    String str = paramf.b();
    a((List)localObject, paramf.a(), str, paramf.c(), paramBoolean);
  }

  protected void A()
  {
    monitorenter;
    try
    {
      Activity localActivity = (Activity)this.b.c.a();
      if (localActivity == null)
        com.google.ads.util.b.e("activity was null while trying to ping click tracking URLs.");
      while (true)
      {
        return;
        Iterator localIterator = this.s.iterator();
        while (localIterator.hasNext())
          new Thread(new aa((String)localIterator.next(), localActivity.getApplicationContext())).start();
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  protected void B()
  {
    monitorenter;
    try
    {
      this.c = null;
      this.k = true;
      this.f.setVisibility(0);
      if (this.b.a())
        a(this.f);
      this.e.c();
      if (this.b.a())
        w();
      com.google.ads.util.b.c("onReceiveAd()");
      AdListener localAdListener = (AdListener)this.b.j.a();
      if (localAdListener != null)
        localAdListener.onReceiveAd((Ad)this.b.f.a());
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public Boolean C()
  {
    return this.u;
  }

  public void a()
  {
    monitorenter;
    try
    {
      this.f = new AdWebView(this.b, ((h)this.b.i.a()).b());
      this.f.setVisibility(8);
      this.g = i.a(this, a.c, true, this.b.b());
      this.f.setWebViewClient(this.g);
      l.a locala = (l.a)((l)this.b.a.a()).a.a();
      if ((AdUtil.a < ((Integer)locala.a.a()).intValue()) && (!((h)this.b.i.a()).a()))
      {
        com.google.ads.util.b.a("Disabling hardware acceleration for a banner.");
        this.f.b();
      }
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void a(float paramFloat)
  {
    monitorenter;
    long l1 = ()(1000.0F * paramFloat);
    try
    {
      this.o = l1;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void a(int paramInt)
  {
    monitorenter;
    try
    {
      this.t = paramInt;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void a(long paramLong)
  {
    synchronized (a)
    {
      SharedPreferences.Editor localEditor = this.n.edit();
      localEditor.putLong("Timeout" + this.b.b, paramLong);
      localEditor.commit();
      if (this.q)
        this.i = paramLong;
      return;
    }
  }

  public void a(View paramView)
  {
    ((ViewGroup)this.b.e.a()).removeAllViews();
    ((ViewGroup)this.b.e.a()).addView(paramView);
  }

  public void a(View paramView, com.google.ads.h paramh, f paramf, boolean paramBoolean)
  {
    monitorenter;
    try
    {
      com.google.ads.util.b.a("AdManager.onReceiveGWhirlAd() called.");
      this.k = true;
      this.x = paramf;
      if (this.b.a())
      {
        a(paramView);
        a(paramf, Boolean.valueOf(paramBoolean));
      }
      this.w.d(paramh);
      AdListener localAdListener = (AdListener)this.b.j.a();
      if (localAdListener != null)
        localAdListener.onReceiveAd((Ad)this.b.f.a());
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void a(AdRequest.ErrorCode paramErrorCode)
  {
    monitorenter;
    try
    {
      this.c = null;
      if (this.b.b())
      {
        if (paramErrorCode != AdRequest.ErrorCode.NO_FILL)
          break label101;
        l().n();
      }
      while (true)
      {
        com.google.ads.util.b.c("onFailedToReceiveAd(" + paramErrorCode + ")");
        AdListener localAdListener = (AdListener)this.b.j.a();
        if (localAdListener != null)
          localAdListener.onFailedToReceiveAd((Ad)this.b.f.a(), paramErrorCode);
        return;
        label101: if (paramErrorCode != AdRequest.ErrorCode.NETWORK_ERROR)
          continue;
        l().l();
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void a(AdRequest paramAdRequest)
  {
    monitorenter;
    while (true)
    {
      try
      {
        if (!o())
          continue;
        com.google.ads.util.b.e("loadAd called while the ad is already loading, so aborting.");
        return;
        if (AdActivity.isShowing())
        {
          com.google.ads.util.b.e("loadAd called while an interstitial or landing page is displayed, so aborting");
          continue;
        }
      }
      finally
      {
        monitorexit;
      }
      if ((!AdUtil.c((Context)this.b.d.a())) || (!AdUtil.b((Context)this.b.d.a())))
        continue;
      long l1 = this.n.getLong("GoogleAdMobDoritosLife", 60000L);
      if (ae.a((Context)this.b.d.a(), l1))
        ae.a((Activity)this.b.c.a());
      this.k = false;
      this.r.clear();
      this.d = paramAdRequest;
      if (this.v.a())
      {
        this.w.a(this.v.b(), paramAdRequest);
        continue;
      }
      this.c = new c(this);
      this.c.a(paramAdRequest);
    }
  }

  public void a(com.google.ads.c paramc)
  {
    monitorenter;
    try
    {
      this.c = null;
      if (paramc.d())
      {
        a(paramc.e());
        if (!r())
          f();
      }
      while (true)
      {
        this.w.a(paramc, this.d);
        return;
        if (!r())
          continue;
        e();
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void a(f paramf, boolean paramBoolean)
  {
    monitorenter;
    try
    {
      Locale localLocale = Locale.US;
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Boolean.valueOf(paramBoolean);
      com.google.ads.util.b.a(String.format(localLocale, "AdManager.onGWhirlAdClicked(%b) called.", arrayOfObject));
      b(paramf, Boolean.valueOf(paramBoolean));
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void a(Runnable paramRunnable)
  {
    this.h.post(paramRunnable);
  }

  public void a(String paramString)
  {
    Uri localUri = new Uri.Builder().encodedQuery(paramString).build();
    StringBuilder localStringBuilder = new StringBuilder();
    HashMap localHashMap = AdUtil.b(localUri);
    Iterator localIterator = localHashMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      localStringBuilder.append(str).append(" = ").append((String)localHashMap.get(str)).append("\n");
    }
    this.y = localStringBuilder.toString().trim();
    if (TextUtils.isEmpty(this.y))
      this.y = null;
  }

  protected void a(LinkedList<String> paramLinkedList)
  {
    monitorenter;
    try
    {
      Iterator localIterator = paramLinkedList.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        com.google.ads.util.b.a("Adding a click tracking URL: " + str);
      }
    }
    finally
    {
      monitorexit;
    }
    this.s = paramLinkedList;
    monitorexit;
  }

  public void a(boolean paramBoolean)
  {
    monitorenter;
    try
    {
      this.j = paramBoolean;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void b()
  {
    monitorenter;
    try
    {
      if (this.w != null)
        this.w.b();
      this.b.j.a(null);
      z();
      if (this.f != null)
        this.f.destroy();
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void b(long paramLong)
  {
    monitorenter;
    if (paramLong > 0L);
    try
    {
      this.n.edit().putLong("GoogleAdMobDoritosLife", paramLong).commit();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void b(com.google.ads.c paramc)
  {
    monitorenter;
    try
    {
      com.google.ads.util.b.a("AdManager.onGWhirlNoFill() called.");
      a(paramc.i(), paramc.c());
      AdListener localAdListener = (AdListener)this.b.j.a();
      if (localAdListener != null)
        localAdListener.onFailedToReceiveAd((Ad)this.b.f.a(), AdRequest.ErrorCode.NO_FILL);
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  protected void b(String paramString)
  {
    monitorenter;
    try
    {
      com.google.ads.util.b.a("Adding a tracking URL: " + paramString);
      this.r.add(paramString);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void b(boolean paramBoolean)
  {
    this.u = Boolean.valueOf(paramBoolean);
  }

  public String c()
  {
    return this.y;
  }

  public void d()
  {
    monitorenter;
    try
    {
      this.m = false;
      com.google.ads.util.b.a("Refreshing is no longer allowed on this AdView.");
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void e()
  {
    monitorenter;
    try
    {
      if (this.l)
      {
        com.google.ads.util.b.a("Disabling refreshing.");
        this.h.removeCallbacks(this.p);
        this.l = false;
      }
      while (true)
      {
        return;
        com.google.ads.util.b.a("Refreshing is already disabled.");
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void f()
  {
    monitorenter;
    while (true)
    {
      try
      {
        if (!this.b.a())
          break label105;
        if (this.m)
        {
          if (this.l)
            continue;
          com.google.ads.util.b.a("Enabling refreshing every " + this.o + " milliseconds.");
          this.h.postDelayed(this.p, this.o);
          this.l = true;
          return;
          com.google.ads.util.b.a("Refreshing is already enabled.");
          continue;
        }
      }
      finally
      {
        monitorexit;
      }
      com.google.ads.util.b.a("Refreshing disabled on this AdView");
      continue;
      label105: com.google.ads.util.b.a("Tried to enable refreshing on something other than an AdView.");
    }
  }

  public m g()
  {
    return this.b;
  }

  public com.google.ads.d h()
  {
    monitorenter;
    try
    {
      com.google.ads.d locald = this.v;
      monitorexit;
      return locald;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public c i()
  {
    monitorenter;
    try
    {
      c localc = this.c;
      monitorexit;
      return localc;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public AdWebView j()
  {
    monitorenter;
    try
    {
      AdWebView localAdWebView = this.f;
      monitorexit;
      return localAdWebView;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public i k()
  {
    monitorenter;
    try
    {
      i locali = this.g;
      monitorexit;
      return locali;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public g l()
  {
    return this.e;
  }

  public int m()
  {
    monitorenter;
    try
    {
      int i1 = this.t;
      monitorexit;
      return i1;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public long n()
  {
    return this.i;
  }

  public boolean o()
  {
    monitorenter;
    try
    {
      c localc = this.c;
      if (localc != null)
      {
        i1 = 1;
        return i1;
      }
      int i1 = 0;
    }
    finally
    {
      monitorexit;
    }
  }

  public boolean p()
  {
    monitorenter;
    try
    {
      boolean bool = this.j;
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public boolean q()
  {
    monitorenter;
    try
    {
      boolean bool = this.k;
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public boolean r()
  {
    monitorenter;
    try
    {
      boolean bool = this.l;
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void s()
  {
    monitorenter;
    try
    {
      this.e.o();
      com.google.ads.util.b.c("onDismissScreen()");
      AdListener localAdListener = (AdListener)this.b.j.a();
      if (localAdListener != null)
        localAdListener.onDismissScreen((Ad)this.b.f.a());
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void t()
  {
    monitorenter;
    try
    {
      com.google.ads.util.b.c("onPresentScreen()");
      AdListener localAdListener = (AdListener)this.b.j.a();
      if (localAdListener != null)
        localAdListener.onPresentScreen((Ad)this.b.f.a());
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void u()
  {
    monitorenter;
    try
    {
      com.google.ads.util.b.c("onLeaveApplication()");
      AdListener localAdListener = (AdListener)this.b.j.a();
      if (localAdListener != null)
        localAdListener.onLeaveApplication((Ad)this.b.f.a());
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void v()
  {
    this.e.b();
    A();
  }

  public void w()
  {
    monitorenter;
    try
    {
      Activity localActivity = (Activity)this.b.c.a();
      if (localActivity == null)
        com.google.ads.util.b.e("activity was null while trying to ping tracking URLs.");
      while (true)
      {
        return;
        Iterator localIterator = this.r.iterator();
        while (localIterator.hasNext())
          new Thread(new aa((String)localIterator.next(), localActivity.getApplicationContext())).start();
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public void x()
  {
    monitorenter;
    while (true)
    {
      try
      {
        if (this.d == null)
          break label100;
        if (this.b.a())
        {
          if ((!((AdView)this.b.g.a()).isShown()) || (!AdUtil.d()))
            continue;
          com.google.ads.util.b.c("Refreshing ad.");
          a(this.d);
          this.h.postDelayed(this.p, this.o);
          return;
          com.google.ads.util.b.a("Not refreshing because the ad is not visible.");
          continue;
        }
      }
      finally
      {
        monitorexit;
      }
      com.google.ads.util.b.a("Tried to refresh an ad that wasn't an AdView.");
      continue;
      label100: com.google.ads.util.b.a("Tried to refresh before calling loadAd().");
    }
  }

  public void y()
  {
    monitorenter;
    while (true)
    {
      try
      {
        com.google.ads.util.a.a(this.b.b());
        if (!q())
          break label101;
        this.k = false;
        if (C() != null)
          continue;
        com.google.ads.util.b.b("isMediationFlag is null in show() with isReady() true. we should have an ad and know whether this is a mediation request or not. ");
        return;
        if (C().booleanValue())
        {
          if (!this.w.c())
            continue;
          a(this.x, Boolean.valueOf(false));
          continue;
        }
      }
      finally
      {
        monitorexit;
      }
      AdActivity.launchAdActivity(this, new e("interstitial"));
      w();
      continue;
      label101: com.google.ads.util.b.c("Cannot show interstitial because it is not loaded and ready.");
    }
  }

  public void z()
  {
    monitorenter;
    try
    {
      if (this.c != null)
      {
        this.c.a();
        this.c = null;
      }
      if (this.f != null)
        this.f.stopLoading();
      return;
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.internal.d
 * JD-Core Version:    0.6.0
 */