package com.google.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.webkit.WebView;
import com.google.ads.AdRequest;
import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.AdSize;
import com.google.ads.l;
import com.google.ads.l.a;
import com.google.ads.m;
import com.google.ads.searchads.SearchAdRequest;
import com.google.ads.util.AdUtil;
import com.google.ads.util.AdUtil.a;
import com.google.ads.util.i.b;
import com.google.ads.util.i.c;
import com.google.ads.util.i.d;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;

public class c
  implements Runnable
{
  private String a;
  private String b;
  private String c;
  private String d;
  private boolean e;
  private f f;
  private d g;
  private AdRequest h;
  private WebView i;
  private String j;
  private LinkedList<String> k;
  private String l;
  private volatile boolean m;
  private boolean n;
  private AdRequest.ErrorCode o;
  private boolean p;
  private int q;
  private Thread r;
  private boolean s;

  protected c()
  {
  }

  public c(d paramd)
  {
    this.g = paramd;
    this.j = null;
    this.a = null;
    this.b = null;
    this.c = null;
    this.k = new LinkedList();
    this.o = null;
    this.p = false;
    this.q = -1;
    this.e = false;
    this.n = false;
    this.l = null;
    if ((Activity)paramd.g().c.a() != null)
    {
      this.i = new AdWebView(paramd.g(), null);
      this.i.setWebViewClient(i.a(paramd, a.b, false, false));
      this.i.setVisibility(8);
      this.i.setWillNotDraw(true);
      this.f = new f(this, paramd);
      return;
    }
    this.i = null;
    this.f = null;
    com.google.ads.util.b.e("activity was null while trying to create an AdLoader.");
  }

  static void a(String paramString, com.google.ads.c paramc, com.google.ads.d paramd)
  {
    if (paramString == null);
    do
      return;
    while ((paramString.contains("no-store")) || (paramString.contains("no-cache")));
    Matcher localMatcher = Pattern.compile("max-age\\s*=\\s*(\\d+)").matcher(paramString);
    if (localMatcher.find())
      try
      {
        int i1 = Integer.parseInt(localMatcher.group(1));
        paramd.a(paramc, i1);
        Locale localLocale = Locale.US;
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(i1);
        com.google.ads.util.b.c(String.format(localLocale, "Caching gWhirl configuration for: %d seconds", arrayOfObject));
        return;
      }
      catch (NumberFormatException localNumberFormatException)
      {
        com.google.ads.util.b.b("Caught exception trying to parse cache control directive. Overflow?", localNumberFormatException);
        return;
      }
    com.google.ads.util.b.c("Unrecognized cacheControlDirective: '" + paramString + "'. Not caching configuration.");
  }

  private String d()
  {
    if ((this.h instanceof SearchAdRequest))
      return "<html><head><script src=\"http://www.gstatic.com/safa/sdk-core-v40.js\"></script><script>";
    return "<html><head><script src=\"http://media.admob.com/sdk-core-v40.js\"></script><script>";
  }

  private void e()
  {
    AdWebView localAdWebView = this.g.j();
    this.g.k().c(true);
    this.g.a(new c(localAdWebView, this.a, this.b));
  }

  private void f()
  {
    this.g.a(new e(this.g, this.k, this.q, this.n, this.l));
  }

  private void f(String paramString)
  {
    this.g.a(new c(this.i, null, paramString));
  }

  public String a(Map<String, Object> paramMap, Activity paramActivity)
    throws c.b, c.d
  {
    Context localContext = paramActivity.getApplicationContext();
    g localg = this.g.l();
    long l1 = localg.h();
    if (l1 > 0L)
      paramMap.put("prl", Long.valueOf(l1));
    String str1 = localg.g();
    if (str1 != null)
      paramMap.put("ppcl", str1);
    String str2 = localg.f();
    if (str2 != null)
      paramMap.put("pcl", str2);
    long l2 = localg.e();
    if (l2 > 0L)
      paramMap.put("pcc", Long.valueOf(l2));
    paramMap.put("preqs", Long.valueOf(localg.i()));
    String str3 = localg.j();
    if (str3 != null)
      paramMap.put("pai", str3);
    if (localg.k())
      paramMap.put("aoi_timeout", "true");
    if (localg.m())
      paramMap.put("aoi_nofill", "true");
    String str4 = localg.p();
    if (str4 != null)
      paramMap.put("pit", str4);
    paramMap.put("ptime", Long.valueOf(g.q()));
    localg.a();
    localg.d();
    if (this.g.g().b())
      paramMap.put("format", "interstitial_mb");
    String str7;
    while (true)
    {
      paramMap.put("slotname", this.g.g().b.a());
      paramMap.put("js", "afma-sdk-a-v6.0.1");
      String str5 = localContext.getPackageName();
      try
      {
        PackageInfo localPackageInfo = localContext.getPackageManager().getPackageInfo(str5, 0);
        int i1 = localPackageInfo.versionCode;
        String str6 = AdUtil.f(localContext);
        if (!TextUtils.isEmpty(str6))
          paramMap.put("mv", str6);
        paramMap.put("msid", localContext.getPackageName());
        paramMap.put("app_name", i1 + ".android." + localContext.getPackageName());
        paramMap.put("isu", AdUtil.a(localContext));
        str7 = AdUtil.d(localContext);
        if (str7 != null)
          break;
        throw new d("NETWORK_ERROR");
        AdSize localAdSize = ((h)this.g.g().i.a()).b();
        if (localAdSize.isFullWidth())
          paramMap.put("smart_w", "full");
        if (localAdSize.isAutoHeight())
          paramMap.put("smart_h", "auto");
        if (!localAdSize.isCustomAdSize())
        {
          paramMap.put("format", localAdSize.toString());
          continue;
        }
        HashMap localHashMap = new HashMap();
        localHashMap.put("w", Integer.valueOf(localAdSize.getWidth()));
        localHashMap.put("h", Integer.valueOf(localAdSize.getHeight()));
        paramMap.put("ad_frame", localHashMap);
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        throw new b("NameNotFoundException");
      }
    }
    paramMap.put("net", str7);
    String str8 = AdUtil.e(localContext);
    if ((str8 != null) && (str8.length() != 0))
      paramMap.put("cap", str8);
    paramMap.put("u_audio", Integer.valueOf(AdUtil.g(localContext).ordinal()));
    DisplayMetrics localDisplayMetrics = AdUtil.a(paramActivity);
    paramMap.put("u_sd", Float.valueOf(localDisplayMetrics.density));
    paramMap.put("u_h", Integer.valueOf(AdUtil.a(localContext, localDisplayMetrics)));
    paramMap.put("u_w", Integer.valueOf(AdUtil.b(localContext, localDisplayMetrics)));
    paramMap.put("hl", Locale.getDefault().getLanguage());
    paramMap.put("carrier", ((TelephonyManager)localContext.getSystemService("phone")).getNetworkOperator());
    if (AdUtil.c())
      paramMap.put("simulator", Integer.valueOf(1));
    paramMap.put("session_id", com.google.ads.b.a().b().toString());
    paramMap.put("seq_num", com.google.ads.b.a().c().toString());
    String str9 = AdUtil.a(paramMap);
    if (((Boolean)((l.a)((l)this.g.g().a.a()).a.a()).l.a()).booleanValue());
    for (String str10 = d() + "AFMA_buildAdURL" + "(" + str9 + ");" + "</script></head><body></body></html>"; ; str10 = d() + "AFMA_getSdkConstants();" + "AFMA_buildAdURL" + "(" + str9 + ");" + "</script></head><body></body></html>")
    {
      com.google.ads.util.b.c("adRequestUrlHtml: " + str10);
      return str10;
    }
  }

  protected void a()
  {
    com.google.ads.util.b.a("AdLoader cancelled.");
    this.i.stopLoading();
    this.i.destroy();
    if (this.r != null)
    {
      this.r.interrupt();
      this.r = null;
    }
    this.f.a();
    this.m = true;
  }

  public void a(int paramInt)
  {
    monitorenter;
    try
    {
      this.q = paramInt;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void a(AdRequest.ErrorCode paramErrorCode)
  {
    monitorenter;
    try
    {
      this.o = paramErrorCode;
      notify();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  protected void a(AdRequest.ErrorCode paramErrorCode, boolean paramBoolean)
  {
    this.f.a();
    this.g.a(new a(this.g, this.i, this.f, paramErrorCode, paramBoolean));
  }

  protected void a(AdRequest paramAdRequest)
  {
    this.h = paramAdRequest;
    this.m = false;
    this.r = new Thread(this);
    this.r.start();
  }

  protected void a(String paramString)
  {
    monitorenter;
    try
    {
      this.k.add(paramString);
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  protected void a(String paramString1, String paramString2)
  {
    monitorenter;
    try
    {
      this.a = paramString2;
      this.b = paramString1;
      notify();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  protected void a(boolean paramBoolean)
  {
    monitorenter;
    try
    {
      this.e = paramBoolean;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  protected void b()
  {
    try
    {
      if (TextUtils.isEmpty(this.d))
      {
        com.google.ads.util.b.b("Got a mediation response with no content type. Aborting mediation.");
        a(AdRequest.ErrorCode.INTERNAL_ERROR, false);
        return;
      }
      if (!this.d.startsWith("application/json"))
      {
        com.google.ads.util.b.b("Got a mediation response with a content type: '" + this.d + "'. Expected something starting with 'application/json'. Aborting mediation.");
        a(AdRequest.ErrorCode.INTERNAL_ERROR, false);
        return;
      }
    }
    catch (JSONException localJSONException)
    {
      com.google.ads.util.b.b("AdLoader can't parse gWhirl server configuration.", localJSONException);
      a(AdRequest.ErrorCode.INTERNAL_ERROR, false);
      return;
    }
    com.google.ads.c localc = com.google.ads.c.a(this.b);
    a(this.c, localc, this.g.h());
    this.g.a(new Runnable(localc)
    {
      public void run()
      {
        c.a(c.this).a(this.a);
      }
    });
  }

  protected void b(String paramString)
  {
    monitorenter;
    try
    {
      this.d = paramString;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void b(boolean paramBoolean)
  {
    monitorenter;
    try
    {
      this.n = paramBoolean;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  protected void c()
  {
    monitorenter;
    try
    {
      this.p = true;
      notify();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  protected void c(String paramString)
  {
    monitorenter;
    try
    {
      this.c = paramString;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void c(boolean paramBoolean)
  {
    this.s = paramBoolean;
  }

  public void d(String paramString)
  {
    monitorenter;
    try
    {
      this.j = paramString;
      notify();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void e(String paramString)
  {
    this.l = paramString;
  }

  // ERROR //
  public void run()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 92	com/google/ads/internal/c:i	Landroid/webkit/WebView;
    //   6: ifnull +10 -> 16
    //   9: aload_0
    //   10: getfield 123	com/google/ads/internal/c:f	Lcom/google/ads/internal/f;
    //   13: ifnonnull +20 -> 33
    //   16: ldc_w 646
    //   19: invokestatic 130	com/google/ads/util/b:e	(Ljava/lang/String;)V
    //   22: aload_0
    //   23: getstatic 608	com/google/ads/AdRequest$ErrorCode:INTERNAL_ERROR	Lcom/google/ads/AdRequest$ErrorCode;
    //   26: iconst_0
    //   27: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   30: aload_0
    //   31: monitorexit
    //   32: return
    //   33: aload_0
    //   34: getfield 43	com/google/ads/internal/c:g	Lcom/google/ads/internal/d;
    //   37: invokevirtual 73	com/google/ads/internal/d:g	()Lcom/google/ads/m;
    //   40: getfield 78	com/google/ads/m:c	Lcom/google/ads/util/i$d;
    //   43: invokevirtual 83	com/google/ads/util/i$d:a	()Ljava/lang/Object;
    //   46: checkcast 85	android/app/Activity
    //   49: astore_3
    //   50: aload_3
    //   51: ifnonnull +25 -> 76
    //   54: ldc_w 648
    //   57: invokestatic 130	com/google/ads/util/b:e	(Ljava/lang/String;)V
    //   60: aload_0
    //   61: getstatic 608	com/google/ads/AdRequest$ErrorCode:INTERNAL_ERROR	Lcom/google/ads/AdRequest$ErrorCode;
    //   64: iconst_0
    //   65: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   68: aload_0
    //   69: monitorexit
    //   70: return
    //   71: astore_2
    //   72: aload_0
    //   73: monitorexit
    //   74: aload_2
    //   75: athrow
    //   76: aload_0
    //   77: getfield 43	com/google/ads/internal/c:g	Lcom/google/ads/internal/d;
    //   80: invokevirtual 650	com/google/ads/internal/d:n	()J
    //   83: lstore 4
    //   85: invokestatic 655	android/os/SystemClock:elapsedRealtime	()J
    //   88: lstore 6
    //   90: aload_0
    //   91: getfield 217	com/google/ads/internal/c:h	Lcom/google/ads/AdRequest;
    //   94: aload_0
    //   95: getfield 43	com/google/ads/internal/c:g	Lcom/google/ads/internal/d;
    //   98: invokevirtual 73	com/google/ads/internal/d:g	()Lcom/google/ads/m;
    //   101: getfield 657	com/google/ads/m:d	Lcom/google/ads/util/i$b;
    //   104: invokevirtual 331	com/google/ads/util/i$b:a	()Ljava/lang/Object;
    //   107: checkcast 337	android/content/Context
    //   110: invokevirtual 663	com/google/ads/AdRequest:getRequestMap	(Landroid/content/Context;)Ljava/util/Map;
    //   113: astore 8
    //   115: aload 8
    //   117: ldc_w 665
    //   120: invokeinterface 669 2 0
    //   125: astore 9
    //   127: aload 9
    //   129: instanceof 272
    //   132: ifeq +113 -> 245
    //   135: aload 9
    //   137: checkcast 272	java/util/Map
    //   140: astore 31
    //   142: aload 31
    //   144: ldc_w 671
    //   147: invokeinterface 669 2 0
    //   152: astore 32
    //   154: aload 32
    //   156: instanceof 138
    //   159: ifeq +12 -> 171
    //   162: aload_0
    //   163: aload 32
    //   165: checkcast 138	java/lang/String
    //   168: putfield 47	com/google/ads/internal/c:a	Ljava/lang/String;
    //   171: aload 31
    //   173: ldc_w 673
    //   176: invokeinterface 669 2 0
    //   181: astore 33
    //   183: aload 33
    //   185: instanceof 138
    //   188: ifeq +19 -> 207
    //   191: aload 33
    //   193: ldc_w 674
    //   196: invokevirtual 677	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   199: ifeq +114 -> 313
    //   202: aload_0
    //   203: iconst_1
    //   204: putfield 62	com/google/ads/internal/c:q	I
    //   207: aload 31
    //   209: ldc_w 679
    //   212: invokeinterface 669 2 0
    //   217: astore 34
    //   219: aload 34
    //   221: instanceof 138
    //   224: ifeq +21 -> 245
    //   227: aload 34
    //   229: ldc_w 681
    //   232: invokevirtual 677	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   235: ifeq +10 -> 245
    //   238: aload_0
    //   239: getfield 43	com/google/ads/internal/c:g	Lcom/google/ads/internal/d;
    //   242: invokevirtual 682	com/google/ads/internal/d:d	()V
    //   245: aload_0
    //   246: getfield 47	com/google/ads/internal/c:a	Ljava/lang/String;
    //   249: astore 10
    //   251: aload 10
    //   253: ifnonnull +428 -> 681
    //   256: aload_0
    //   257: aload 8
    //   259: aload_3
    //   260: invokevirtual 684	com/google/ads/internal/c:a	(Ljava/util/Map;Landroid/app/Activity;)Ljava/lang/String;
    //   263: astore 18
    //   265: aload_0
    //   266: aload 18
    //   268: invokespecial 686	com/google/ads/internal/c:f	(Ljava/lang/String;)V
    //   271: invokestatic 655	android/os/SystemClock:elapsedRealtime	()J
    //   274: lstore 19
    //   276: lload 4
    //   278: lload 19
    //   280: lload 6
    //   282: lsub
    //   283: lsub
    //   284: lstore 21
    //   286: lload 21
    //   288: lconst_0
    //   289: lcmp
    //   290: ifle +9 -> 299
    //   293: aload_0
    //   294: lload 21
    //   296: invokevirtual 690	java/lang/Object:wait	(J)V
    //   299: aload_0
    //   300: getfield 574	com/google/ads/internal/c:m	Z
    //   303: istore 23
    //   305: iload 23
    //   307: ifeq +147 -> 454
    //   310: aload_0
    //   311: monitorexit
    //   312: return
    //   313: aload 33
    //   315: ldc_w 691
    //   318: invokevirtual 677	java/lang/Object:equals	(Ljava/lang/Object;)Z
    //   321: ifeq -114 -> 207
    //   324: aload_0
    //   325: iconst_0
    //   326: putfield 62	com/google/ads/internal/c:q	I
    //   329: goto -122 -> 207
    //   332: astore_1
    //   333: ldc_w 693
    //   336: aload_1
    //   337: invokestatic 200	com/google/ads/util/b:b	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   340: aload_0
    //   341: getstatic 608	com/google/ads/AdRequest$ErrorCode:INTERNAL_ERROR	Lcom/google/ads/AdRequest$ErrorCode;
    //   344: iconst_1
    //   345: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   348: aload_0
    //   349: monitorexit
    //   350: return
    //   351: astore 17
    //   353: new 202	java/lang/StringBuilder
    //   356: dup
    //   357: invokespecial 203	java/lang/StringBuilder:<init>	()V
    //   360: ldc_w 695
    //   363: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   366: aload 17
    //   368: invokevirtual 698	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   371: invokevirtual 215	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   374: invokestatic 195	com/google/ads/util/b:c	(Ljava/lang/String;)V
    //   377: aload_0
    //   378: getstatic 700	com/google/ads/AdRequest$ErrorCode:NETWORK_ERROR	Lcom/google/ads/AdRequest$ErrorCode;
    //   381: iconst_0
    //   382: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   385: aload_0
    //   386: monitorexit
    //   387: return
    //   388: astore 16
    //   390: new 202	java/lang/StringBuilder
    //   393: dup
    //   394: invokespecial 203	java/lang/StringBuilder:<init>	()V
    //   397: ldc_w 702
    //   400: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   403: aload 16
    //   405: invokevirtual 698	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   408: invokevirtual 215	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   411: invokestatic 195	com/google/ads/util/b:c	(Ljava/lang/String;)V
    //   414: aload_0
    //   415: getstatic 608	com/google/ads/AdRequest$ErrorCode:INTERNAL_ERROR	Lcom/google/ads/AdRequest$ErrorCode;
    //   418: iconst_0
    //   419: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   422: aload_0
    //   423: monitorexit
    //   424: return
    //   425: astore 30
    //   427: new 202	java/lang/StringBuilder
    //   430: dup
    //   431: invokespecial 203	java/lang/StringBuilder:<init>	()V
    //   434: ldc_w 704
    //   437: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   440: aload 30
    //   442: invokevirtual 698	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   445: invokevirtual 215	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   448: invokestatic 558	com/google/ads/util/b:a	(Ljava/lang/String;)V
    //   451: aload_0
    //   452: monitorexit
    //   453: return
    //   454: aload_0
    //   455: getfield 58	com/google/ads/internal/c:o	Lcom/google/ads/AdRequest$ErrorCode;
    //   458: ifnull +15 -> 473
    //   461: aload_0
    //   462: aload_0
    //   463: getfield 58	com/google/ads/internal/c:o	Lcom/google/ads/AdRequest$ErrorCode;
    //   466: iconst_0
    //   467: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   470: aload_0
    //   471: monitorexit
    //   472: return
    //   473: aload_0
    //   474: getfield 45	com/google/ads/internal/c:j	Ljava/lang/String;
    //   477: ifnonnull +44 -> 521
    //   480: new 202	java/lang/StringBuilder
    //   483: dup
    //   484: invokespecial 203	java/lang/StringBuilder:<init>	()V
    //   487: ldc_w 706
    //   490: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   493: lload 4
    //   495: invokevirtual 709	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   498: ldc_w 711
    //   501: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   504: invokevirtual 215	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   507: invokestatic 195	com/google/ads/util/b:c	(Ljava/lang/String;)V
    //   510: aload_0
    //   511: getstatic 700	com/google/ads/AdRequest$ErrorCode:NETWORK_ERROR	Lcom/google/ads/AdRequest$ErrorCode;
    //   514: iconst_0
    //   515: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   518: aload_0
    //   519: monitorexit
    //   520: return
    //   521: aload_0
    //   522: getfield 123	com/google/ads/internal/c:f	Lcom/google/ads/internal/f;
    //   525: aload_0
    //   526: getfield 639	com/google/ads/internal/c:s	Z
    //   529: invokevirtual 713	com/google/ads/internal/f:a	(Z)V
    //   532: aload_0
    //   533: getfield 123	com/google/ads/internal/c:f	Lcom/google/ads/internal/f;
    //   536: aload_0
    //   537: getfield 45	com/google/ads/internal/c:j	Ljava/lang/String;
    //   540: invokevirtual 714	com/google/ads/internal/f:a	(Ljava/lang/String;)V
    //   543: invokestatic 655	android/os/SystemClock:elapsedRealtime	()J
    //   546: lstore 24
    //   548: lload 4
    //   550: lload 24
    //   552: lload 6
    //   554: lsub
    //   555: lsub
    //   556: lstore 26
    //   558: lload 26
    //   560: lconst_0
    //   561: lcmp
    //   562: ifle +9 -> 571
    //   565: aload_0
    //   566: lload 26
    //   568: invokevirtual 690	java/lang/Object:wait	(J)V
    //   571: aload_0
    //   572: getfield 574	com/google/ads/internal/c:m	Z
    //   575: istore 28
    //   577: iload 28
    //   579: ifeq +35 -> 614
    //   582: aload_0
    //   583: monitorexit
    //   584: return
    //   585: astore 29
    //   587: new 202	java/lang/StringBuilder
    //   590: dup
    //   591: invokespecial 203	java/lang/StringBuilder:<init>	()V
    //   594: ldc_w 716
    //   597: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   600: aload 29
    //   602: invokevirtual 698	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   605: invokevirtual 215	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   608: invokestatic 558	com/google/ads/util/b:a	(Ljava/lang/String;)V
    //   611: aload_0
    //   612: monitorexit
    //   613: return
    //   614: aload_0
    //   615: getfield 58	com/google/ads/internal/c:o	Lcom/google/ads/AdRequest$ErrorCode;
    //   618: ifnull +15 -> 633
    //   621: aload_0
    //   622: aload_0
    //   623: getfield 58	com/google/ads/internal/c:o	Lcom/google/ads/AdRequest$ErrorCode;
    //   626: iconst_0
    //   627: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   630: aload_0
    //   631: monitorexit
    //   632: return
    //   633: aload_0
    //   634: getfield 49	com/google/ads/internal/c:b	Ljava/lang/String;
    //   637: ifnonnull +44 -> 681
    //   640: new 202	java/lang/StringBuilder
    //   643: dup
    //   644: invokespecial 203	java/lang/StringBuilder:<init>	()V
    //   647: ldc_w 706
    //   650: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   653: lload 4
    //   655: invokevirtual 709	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   658: ldc_w 718
    //   661: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   664: invokevirtual 215	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   667: invokestatic 195	com/google/ads/util/b:c	(Ljava/lang/String;)V
    //   670: aload_0
    //   671: getstatic 700	com/google/ads/AdRequest$ErrorCode:NETWORK_ERROR	Lcom/google/ads/AdRequest$ErrorCode;
    //   674: iconst_0
    //   675: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   678: aload_0
    //   679: monitorexit
    //   680: return
    //   681: aload_0
    //   682: getfield 64	com/google/ads/internal/c:e	Z
    //   685: ifeq +18 -> 703
    //   688: aload_0
    //   689: getfield 43	com/google/ads/internal/c:g	Lcom/google/ads/internal/d;
    //   692: iconst_1
    //   693: invokevirtual 720	com/google/ads/internal/d:b	(Z)V
    //   696: aload_0
    //   697: invokevirtual 722	com/google/ads/internal/c:b	()V
    //   700: aload_0
    //   701: monitorexit
    //   702: return
    //   703: aload_0
    //   704: getfield 599	com/google/ads/internal/c:d	Ljava/lang/String;
    //   707: ifnull +72 -> 779
    //   710: aload_0
    //   711: getfield 599	com/google/ads/internal/c:d	Ljava/lang/String;
    //   714: ldc_w 612
    //   717: invokevirtual 616	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   720: ifne +16 -> 736
    //   723: aload_0
    //   724: getfield 599	com/google/ads/internal/c:d	Ljava/lang/String;
    //   727: ldc_w 724
    //   730: invokevirtual 616	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   733: ifeq +46 -> 779
    //   736: new 202	java/lang/StringBuilder
    //   739: dup
    //   740: invokespecial 203	java/lang/StringBuilder:<init>	()V
    //   743: ldc_w 726
    //   746: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   749: aload_0
    //   750: getfield 599	com/google/ads/internal/c:d	Ljava/lang/String;
    //   753: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   756: ldc_w 728
    //   759: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   762: invokevirtual 215	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   765: invokestatic 603	com/google/ads/util/b:b	(Ljava/lang/String;)V
    //   768: aload_0
    //   769: getstatic 608	com/google/ads/AdRequest$ErrorCode:INTERNAL_ERROR	Lcom/google/ads/AdRequest$ErrorCode;
    //   772: iconst_0
    //   773: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   776: aload_0
    //   777: monitorexit
    //   778: return
    //   779: aload_0
    //   780: getfield 43	com/google/ads/internal/c:g	Lcom/google/ads/internal/d;
    //   783: iconst_0
    //   784: invokevirtual 720	com/google/ads/internal/d:b	(Z)V
    //   787: aload_0
    //   788: invokespecial 730	com/google/ads/internal/c:e	()V
    //   791: invokestatic 655	android/os/SystemClock:elapsedRealtime	()J
    //   794: lstore 11
    //   796: lload 4
    //   798: lload 11
    //   800: lload 6
    //   802: lsub
    //   803: lsub
    //   804: lstore 13
    //   806: lload 13
    //   808: lconst_0
    //   809: lcmp
    //   810: ifle +9 -> 819
    //   813: aload_0
    //   814: lload 13
    //   816: invokevirtual 690	java/lang/Object:wait	(J)V
    //   819: aload_0
    //   820: getfield 60	com/google/ads/internal/c:p	Z
    //   823: ifeq +39 -> 862
    //   826: aload_0
    //   827: invokespecial 732	com/google/ads/internal/c:f	()V
    //   830: goto -482 -> 348
    //   833: astore 15
    //   835: new 202	java/lang/StringBuilder
    //   838: dup
    //   839: invokespecial 203	java/lang/StringBuilder:<init>	()V
    //   842: ldc_w 734
    //   845: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   848: aload 15
    //   850: invokevirtual 698	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   853: invokevirtual 215	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   856: invokestatic 558	com/google/ads/util/b:a	(Ljava/lang/String;)V
    //   859: aload_0
    //   860: monitorexit
    //   861: return
    //   862: new 202	java/lang/StringBuilder
    //   865: dup
    //   866: invokespecial 203	java/lang/StringBuilder:<init>	()V
    //   869: ldc_w 706
    //   872: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   875: lload 4
    //   877: invokevirtual 709	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   880: ldc_w 736
    //   883: invokevirtual 209	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   886: invokevirtual 215	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   889: invokestatic 195	com/google/ads/util/b:c	(Ljava/lang/String;)V
    //   892: aload_0
    //   893: getstatic 700	com/google/ads/AdRequest$ErrorCode:NETWORK_ERROR	Lcom/google/ads/AdRequest$ErrorCode;
    //   896: iconst_1
    //   897: invokevirtual 610	com/google/ads/internal/c:a	(Lcom/google/ads/AdRequest$ErrorCode;Z)V
    //   900: goto -552 -> 348
    //
    // Exception table:
    //   from	to	target	type
    //   2	16	71	finally
    //   16	30	71	finally
    //   30	32	71	finally
    //   33	50	71	finally
    //   54	68	71	finally
    //   68	70	71	finally
    //   72	74	71	finally
    //   76	171	71	finally
    //   171	207	71	finally
    //   207	245	71	finally
    //   245	251	71	finally
    //   256	265	71	finally
    //   265	276	71	finally
    //   293	299	71	finally
    //   299	305	71	finally
    //   310	312	71	finally
    //   313	329	71	finally
    //   333	348	71	finally
    //   348	350	71	finally
    //   353	385	71	finally
    //   385	387	71	finally
    //   390	422	71	finally
    //   422	424	71	finally
    //   427	451	71	finally
    //   451	453	71	finally
    //   454	470	71	finally
    //   470	472	71	finally
    //   473	518	71	finally
    //   518	520	71	finally
    //   521	548	71	finally
    //   565	571	71	finally
    //   571	577	71	finally
    //   582	584	71	finally
    //   587	611	71	finally
    //   611	613	71	finally
    //   614	630	71	finally
    //   630	632	71	finally
    //   633	678	71	finally
    //   678	680	71	finally
    //   681	700	71	finally
    //   700	702	71	finally
    //   703	736	71	finally
    //   736	776	71	finally
    //   776	778	71	finally
    //   779	796	71	finally
    //   813	819	71	finally
    //   819	830	71	finally
    //   835	859	71	finally
    //   859	861	71	finally
    //   862	900	71	finally
    //   2	16	332	java/lang/Throwable
    //   16	30	332	java/lang/Throwable
    //   33	50	332	java/lang/Throwable
    //   54	68	332	java/lang/Throwable
    //   76	171	332	java/lang/Throwable
    //   171	207	332	java/lang/Throwable
    //   207	245	332	java/lang/Throwable
    //   245	251	332	java/lang/Throwable
    //   256	265	332	java/lang/Throwable
    //   265	276	332	java/lang/Throwable
    //   293	299	332	java/lang/Throwable
    //   299	305	332	java/lang/Throwable
    //   313	329	332	java/lang/Throwable
    //   353	385	332	java/lang/Throwable
    //   390	422	332	java/lang/Throwable
    //   427	451	332	java/lang/Throwable
    //   454	470	332	java/lang/Throwable
    //   473	518	332	java/lang/Throwable
    //   521	548	332	java/lang/Throwable
    //   565	571	332	java/lang/Throwable
    //   571	577	332	java/lang/Throwable
    //   587	611	332	java/lang/Throwable
    //   614	630	332	java/lang/Throwable
    //   633	678	332	java/lang/Throwable
    //   681	700	332	java/lang/Throwable
    //   703	736	332	java/lang/Throwable
    //   736	776	332	java/lang/Throwable
    //   779	796	332	java/lang/Throwable
    //   813	819	332	java/lang/Throwable
    //   819	830	332	java/lang/Throwable
    //   835	859	332	java/lang/Throwable
    //   862	900	332	java/lang/Throwable
    //   256	265	351	com/google/ads/internal/c$d
    //   256	265	388	com/google/ads/internal/c$b
    //   293	299	425	java/lang/InterruptedException
    //   565	571	585	java/lang/InterruptedException
    //   813	819	833	java/lang/InterruptedException
  }

  private static class a
    implements Runnable
  {
    private final d a;
    private final WebView b;
    private final f c;
    private final AdRequest.ErrorCode d;
    private final boolean e;

    public a(d paramd, WebView paramWebView, f paramf, AdRequest.ErrorCode paramErrorCode, boolean paramBoolean)
    {
      this.a = paramd;
      this.b = paramWebView;
      this.c = paramf;
      this.d = paramErrorCode;
      this.e = paramBoolean;
    }

    public void run()
    {
      if (this.b != null)
      {
        this.b.stopLoading();
        this.b.destroy();
      }
      if (this.c != null)
        this.c.a();
      if (this.e)
      {
        AdWebView localAdWebView = this.a.j();
        localAdWebView.stopLoading();
        localAdWebView.setVisibility(8);
      }
      this.a.a(this.d);
    }
  }

  private class b extends Exception
  {
    public b(String arg2)
    {
      super();
    }
  }

  private class c
    implements Runnable
  {
    private final String b;
    private final String c;
    private final WebView d;

    public c(WebView paramString1, String paramString2, String arg4)
    {
      this.d = paramString1;
      this.b = paramString2;
      Object localObject;
      this.c = localObject;
    }

    public void run()
    {
      if (this.c != null)
      {
        this.d.loadDataWithBaseURL(this.b, this.c, "text/html", "utf-8", null);
        return;
      }
      this.d.loadUrl(this.b);
    }
  }

  private class d extends Exception
  {
    public d(String arg2)
    {
      super();
    }
  }

  private static class e
    implements Runnable
  {
    private final d a;
    private final LinkedList<String> b;
    private final int c;
    private final boolean d;
    private final String e;

    public e(d paramd, LinkedList<String> paramLinkedList, int paramInt, boolean paramBoolean, String paramString)
    {
      this.a = paramd;
      this.b = paramLinkedList;
      this.c = paramInt;
      this.d = paramBoolean;
      this.e = paramString;
    }

    public void run()
    {
      this.a.a(this.b);
      this.a.a(this.c);
      this.a.a(this.d);
      if (!TextUtils.isEmpty(this.e))
        this.a.a(this.e);
      this.a.B();
    }
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.internal.c
 * JD-Core Version:    0.6.0
 */