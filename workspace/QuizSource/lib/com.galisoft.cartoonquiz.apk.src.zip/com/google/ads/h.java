package com.google.ads;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.util.a;
import com.google.ads.util.b;
import java.util.HashMap;

public class h
{
  final com.google.ads.internal.h a;
  private final f b;
  private boolean c;
  private boolean d;
  private final e e;
  private MediationAdapter<?, ?> f;
  private boolean g;
  private boolean h;
  private View i;
  private final Handler j;
  private final String k;
  private final AdRequest l;
  private final HashMap<String, String> m;

  public h(e parame, com.google.ads.internal.h paramh, f paramf, String paramString, AdRequest paramAdRequest, HashMap<String, String> paramHashMap)
  {
    a.b(TextUtils.isEmpty(paramString));
    this.e = parame;
    this.a = paramh;
    this.b = paramf;
    this.k = paramString;
    this.l = paramAdRequest;
    this.m = paramHashMap;
    this.c = false;
    this.d = false;
    this.f = null;
    this.g = false;
    this.h = false;
    this.i = null;
    this.j = new Handler(Looper.getMainLooper());
  }

  public f a()
  {
    return this.b;
  }

  public void a(Activity paramActivity)
  {
    monitorenter;
    try
    {
      a.b(this.g, "startLoadAdTask has already been called.");
      this.g = true;
      this.j.post(new i(this, paramActivity, this.k, this.l, this.m));
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  void a(View paramView)
  {
    monitorenter;
    try
    {
      this.i = paramView;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  void a(MediationAdapter<?, ?> paramMediationAdapter)
  {
    monitorenter;
    try
    {
      this.f = paramMediationAdapter;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  void a(boolean paramBoolean)
  {
    monitorenter;
    try
    {
      this.d = paramBoolean;
      this.c = true;
      notify();
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void b()
  {
    monitorenter;
    try
    {
      a.a(this.g, "destroy() called but startLoadAdTask has not been called.");
      this.j.post(new Runnable()
      {
        public void run()
        {
          if (h.this.k())
            a.b(h.a(h.this));
          try
          {
            h.a(h.this).destroy();
            b.a("Called destroy() for adapter with class: " + h.a(h.this).getClass().getName());
            return;
          }
          catch (Throwable localThrowable)
          {
            b.b("Error while destroying adapter (" + h.this.g() + "):", localThrowable);
          }
        }
      });
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public boolean c()
  {
    monitorenter;
    try
    {
      boolean bool = this.c;
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public boolean d()
  {
    monitorenter;
    try
    {
      a.a(c(), "isLoadAdTaskSuccessful() called when isLoadAdTaskDone() is false.");
      boolean bool = this.d;
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public View e()
  {
    monitorenter;
    try
    {
      a.a(c(), "getAdView() called when isLoadAdTaskDone() is false.");
      View localView = this.i;
      monitorexit;
      return localView;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void f()
  {
    monitorenter;
    try
    {
      a.a(this.a.a());
      try
      {
        MediationInterstitialAdapter localMediationInterstitialAdapter = (MediationInterstitialAdapter)this.f;
        this.j.post(new Runnable(localMediationInterstitialAdapter)
        {
          public void run()
          {
            try
            {
              this.a.showInterstitial();
              return;
            }
            catch (Throwable localThrowable)
            {
              b.b("Error while telling adapter (" + h.this.g() + ") ad to show interstitial: ", localThrowable);
            }
          }
        });
        monitorexit;
        return;
      }
      catch (ClassCastException localClassCastException)
      {
        while (true)
          b.b("In Ambassador.show(): ambassador.adapter does not implement the MediationInterstitialAdapter interface.", localClassCastException);
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public String g()
  {
    monitorenter;
    try
    {
      if (this.f != null)
      {
        String str2 = this.f.getClass().getName();
        str1 = str2;
        return str1;
      }
      String str1 = "\"adapter was not created.\"";
    }
    finally
    {
      monitorexit;
    }
  }

  MediationAdapter<?, ?> h()
  {
    monitorenter;
    try
    {
      MediationAdapter localMediationAdapter = this.f;
      monitorexit;
      return localMediationAdapter;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  e i()
  {
    return this.e;
  }

  void j()
  {
    monitorenter;
    try
    {
      this.h = true;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  boolean k()
  {
    monitorenter;
    try
    {
      boolean bool = this.h;
      monitorexit;
      return bool;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.h
 * JD-Core Version:    0.6.0
 */