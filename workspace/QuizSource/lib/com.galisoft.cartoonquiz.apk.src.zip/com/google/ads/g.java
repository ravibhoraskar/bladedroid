package com.google.ads;

public final class g
{
  public static <T> T a(String paramString, Class<T> paramClass)
    throws ClassNotFoundException, ClassCastException, IllegalAccessException, InstantiationException, LinkageError, ExceptionInInitializerError
  {
    return paramClass.cast(Class.forName(paramString).newInstance());
  }

  public static String a(String paramString1, String paramString2, Boolean paramBoolean, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8)
  {
    String str1 = paramString1.replaceAll("@gw_adlocid@", paramString2).replaceAll("@gw_qdata@", paramString6).replaceAll("@gw_sdkver@", "afma-sdk-a-v6.0.1").replaceAll("@gw_sessid@", paramString7).replaceAll("@gw_seqnum@", paramString8).replaceAll("@gw_devid@", paramString3);
    if (paramString5 != null)
      str1 = str1.replaceAll("@gw_adnetid@", paramString5);
    if (paramString4 != null)
      str1 = str1.replaceAll("@gw_allocid@", paramString4);
    if (paramBoolean != null)
    {
      if (paramBoolean.booleanValue());
      for (String str2 = "1"; ; str2 = "0")
        return str1.replaceAll("@gw_adnetrefresh@", str2);
    }
    return str1;
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.g
 * JD-Core Version:    0.6.0
 */