package com.google.ads;

import java.util.HashMap;
import java.util.List;

public class a
{
  private final String a;
  private final String b;
  private final List<String> c;
  private final HashMap<String, String> d;

  public a(String paramString1, String paramString2, List<String> paramList, HashMap<String, String> paramHashMap)
  {
    com.google.ads.util.a.a(paramString2);
    if (paramString1 != null)
      com.google.ads.util.a.a(paramString1);
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramList;
    this.d = paramHashMap;
  }

  public String a()
  {
    return this.a;
  }

  public String b()
  {
    return this.b;
  }

  public List<String> c()
  {
    return this.c;
  }

  public HashMap<String, String> d()
  {
    return this.d;
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.a
 * JD-Core Version:    0.6.0
 */