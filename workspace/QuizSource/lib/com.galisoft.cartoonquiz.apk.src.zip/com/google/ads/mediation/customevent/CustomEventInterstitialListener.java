package com.google.ads.mediation.customevent;

public abstract interface CustomEventInterstitialListener extends CustomEventListener
{
  public abstract void onReceivedAd();
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.mediation.customevent.CustomEventInterstitialListener
 * JD-Core Version:    0.6.0
 */