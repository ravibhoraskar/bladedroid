package com.google.ads;

import android.net.Uri;

public class ac
{
  public static final Uri a = Uri.parse("content://com.google.plus.platform/ads");
  public static final Uri b = Uri.parse("content://com.google.plus.platform/token");
  public static final String[] c = { "_id", "has_plus1" };
  public static final String[] d = { "drt" };
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.ac
 * JD-Core Version:    0.6.0
 */