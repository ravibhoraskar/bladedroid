package com.google.ads;

import android.content.Context;
import android.webkit.WebView;
import com.google.ads.internal.d;
import com.google.ads.util.b;
import java.util.HashMap;

public class s
  implements n
{
  protected Runnable a(String paramString, WebView paramWebView)
  {
    return new aa(paramString, paramWebView.getContext().getApplicationContext());
  }

  public void a(d paramd, HashMap<String, String> paramHashMap, WebView paramWebView)
  {
    String str = (String)paramHashMap.get("u");
    if (str == null)
    {
      b.e("Could not get URL from click gmsg.");
      return;
    }
    new Thread(a(str, paramWebView)).start();
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.s
 * JD-Core Version:    0.6.0
 */