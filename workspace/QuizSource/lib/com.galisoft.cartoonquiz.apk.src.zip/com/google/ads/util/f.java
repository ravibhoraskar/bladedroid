package com.google.ads.util;

public abstract interface f<T>
{
  public abstract T b();
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.util.f
 * JD-Core Version:    0.6.0
 */