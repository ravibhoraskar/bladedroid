package com.google.ads.util;

import android.view.View;
import android.webkit.WebChromeClient.CustomViewCallback;
import com.google.ads.m;

public class h
{
  public static class a extends g.a
  {
    public a(m paramm)
    {
      super();
    }

    public void onShowCustomView(View paramView, int paramInt, WebChromeClient.CustomViewCallback paramCustomViewCallback)
    {
      paramCustomViewCallback.onCustomViewHidden();
    }
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.util.h
 * JD-Core Version:    0.6.0
 */