package com.google.ads;

import android.webkit.WebView;
import com.google.ads.internal.d;
import java.util.HashMap;

public class y
  implements n
{
  public void a(d paramd, HashMap<String, String> paramHashMap, WebView paramWebView)
  {
  }
}

/* Location:           /Users/dola/Desktop/quiz/com.galisoft.cartoonquiz.apk.jar
 * Qualified Name:     com.google.ads.y
 * JD-Core Version:    0.6.0
 */